ReadME
--------------------------------------------
TO RUN GREEDY ALGORITHM
	make greedyChange

TO RUN RECURSIVE ALGORITHM
	make recursiveChange

TO RUN DYNAMIC ALGORITHM
	make dynamicChange

TO RUN ALL ALGORITHMS
	make all
--------------------------------------------
IF YOU WANT TO RUN WITHOUT MAKEFILE
g++ <cpp file name> -o <choose object filename>
./<object filename you chose> <change> <number of coins> 
	<enter different amount of coin values for the number of coins you have>
--------------------------------------------